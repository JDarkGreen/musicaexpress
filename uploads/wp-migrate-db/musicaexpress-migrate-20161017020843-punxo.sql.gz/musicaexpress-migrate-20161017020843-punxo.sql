# WordPress MySQL database migration
#
# Generated: Monday 17. October 2016 02:08 UTC
# Hostname: localhost
# Database: `musicaexpress`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

